import { SlimscrollDirective } from './slimscroll.directive';

describe('SlimscrollDirective', () => {
  it('should create an instance', () => {
    const directive = new SlimscrollDirective();
    expect(directive).toBeTruthy();
  });
});
