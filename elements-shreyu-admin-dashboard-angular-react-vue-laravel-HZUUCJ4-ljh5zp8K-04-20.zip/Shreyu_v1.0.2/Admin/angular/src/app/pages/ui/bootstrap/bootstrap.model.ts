export interface Color {
    color: string;
}
