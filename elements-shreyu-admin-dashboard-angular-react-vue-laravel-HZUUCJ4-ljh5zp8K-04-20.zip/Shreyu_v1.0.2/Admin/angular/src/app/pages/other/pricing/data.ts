const pricingData = [
    {
        pack: 'Professional Pack',
        icon: 'users',
        price: '$19',
        storage: 10,
        bandwidth: '500',
        domain: 'No'
    },
    {
        pack: 'Business Pack',
        icon: 'briefcase',
        price: '$29',
        storage: 50,
        bandwidth: '900',
        domain: '2'
    },
    {
        pack: 'Enterprise Pack',
        icon: 'shopping-bag',
        price: '$49',
        storage: 100,
        bandwidth: 'Unlimited',
        domain: 'Unlimited'
    },
];

export { pricingData };
